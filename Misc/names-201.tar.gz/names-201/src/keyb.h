/* keyb.h */

void kb_init();
void kb_done();
void kb_shell();
void kb_wait();
void kb_nowait();
void kb_timeout();


